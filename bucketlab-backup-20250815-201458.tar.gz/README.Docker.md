### Building and running your application

When you're ready, start your application by running:
`docker compose up --build --remove-orphans -d`.

Your application will be available at http://localhost:4020.

### References
* [Docker's Node.js guide](https://docs.docker.com/language/nodejs/)