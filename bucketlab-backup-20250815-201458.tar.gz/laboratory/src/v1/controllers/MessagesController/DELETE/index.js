const { delete_message_by_message_id } = require('./delete_message_by_message_id.js');

module.exports = Object.freeze(
  Object.assign({},
    { delete_message_by_message_id }
  )
);