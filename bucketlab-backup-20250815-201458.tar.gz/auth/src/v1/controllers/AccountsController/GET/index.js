const { get_all_accounts } = require('./get_all_accounts');
const { get_account_by_account_id } = require('./get_account_by_account_id');

module.exports = Object.freeze(
  Object.assign({},
    { get_all_accounts },
    { get_account_by_account_id }
  )
);