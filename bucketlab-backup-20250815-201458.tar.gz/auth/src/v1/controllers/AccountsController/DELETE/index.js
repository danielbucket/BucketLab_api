const { delete_account_by_account_id } = require('./delete_account_by_account_id');

module.exports = Object.freeze(
  Object.assign({},
    { delete_account_by_account_id }
  )
);