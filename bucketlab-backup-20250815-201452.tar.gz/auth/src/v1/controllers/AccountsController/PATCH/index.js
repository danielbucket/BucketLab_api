const { update_account_by_account_id } = require('./update_account_by_account_id');

module.exports = Object.freeze(
  Object.assign({},
    { update_account_by_account_id }
  )
);