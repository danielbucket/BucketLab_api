const { update_message_by_message_id } = require('./update_message_by_message_id');

module.exports = Object.freeze(
  Object.assign({},
    { update_message_by_message_id }
  )
);