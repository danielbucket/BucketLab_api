const { new_message } = require('./new_message.js');

module.exports = Object.freeze(
  Object.assign({},
    { new_message }
  )
);
